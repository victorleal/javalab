import java.util.List;


public class Cliente extends Pessoa{

	private Boolean isClienteFidelidade;
	private String programaFidelidade;
	private String numeroFidelidade;
	private List<Pedido> pedidosCliente;
	
	public Boolean getIsClienteFidelidade() {
		return isClienteFidelidade;
	}
	public void setIsClienteFidelidade(Boolean isClienteFidelidade) {
		this.isClienteFidelidade = isClienteFidelidade;
	}
	public String getProgramaFidelidade() {
		return programaFidelidade;
	}
	public void setProgramaFidelidade(String programaFidelidade) {
		this.programaFidelidade = programaFidelidade;
	}
	public String getNumeroFidelidade() {
		return numeroFidelidade;
	}
	public void setNumeroFidelidade(String numeroFidelidade) {
		this.numeroFidelidade = numeroFidelidade;
	}
	
	public Cliente(String nome, String cpf, String email, String telefone,
			String celular, Endereco endereco, Boolean isClienteFidelidade,
			String programaFidelidade, String numeroFidelidade,
			List<Pedido> pedidosCliente) {
		super(nome, cpf, email, telefone, celular, endereco);
		this.isClienteFidelidade = isClienteFidelidade;
		this.programaFidelidade = programaFidelidade;
		this.numeroFidelidade = numeroFidelidade;
		this.pedidosCliente = pedidosCliente;
	}
	

}
