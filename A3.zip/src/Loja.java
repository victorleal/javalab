import java.util.List;


public class Loja {
	
	private List<Cliente> clientes;
	private List<Pedido> pedidos;
	private List<Transportadora> transportadora;
	private List<Produto> produtos;
	
	public void cadastrarProduto() 
	{
		
	}
	
	public void removerProduto(int id)
	{
		
	}

	public void consultarProduto(int id)
	{
		
	}
	
	public void alterarProduto(Produto prod, double valor)
	{
		
	}
	
	public void alterarProduto(Produto prod, int estoque)
	{
		
	}
	
	public void cadastrarCliente()
	{
		
	}
	
	public void consultarCliente(String cpf)
	{
		
	}
	
	public void removerCliente(String cpf)
	{
		
	}
	
	public void alterarCliente()
	{
		
	}
	
	public void cadastrarTransportadora()
	{
		
	}
	
	public void removerTransportadora(String cnpj)
	{
		
	}
	
	public void consultarTransportadora(String cnpj)
	{
		
	}
	
	public void alterarTransportadora(Transportadora transp, int prazo)
	{
		
	}
	
	public void alterarTransportadora(Transportadora transp, double taxa)
	{
		
	}
	
	public void cadastrarPedido()
	{
		
	}
	
	public void consultarPedido(String numero)
	{
		
	}
	
	public void cancelarPedido(String numero)
	{
		
	}
	
	public void getFaturamentoBruto()
	{
		
	}
	
	public void getValorDevidoTransportadora(String cnpj)
	{
		
	}
	
	public void getValorDevidoTotal()
	{
		
	}
	
	public void getFaturamentoLiquido()
	{
		
	}

	public Loja(List<Cliente> clientes, List<Pedido> pedidos,
			List<Transportadora> transportadora, List<Produto> produtos) {
		super();
		this.clientes = clientes;
		this.pedidos = pedidos;
		this.transportadora = transportadora;
		this.produtos = produtos;
	}
	
	
}

