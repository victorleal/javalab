import java.util.List;


public class Produto {
	
	private int id;
	private String categoria;
	private String counteudodaCaixa;
	private String descricao;
	private double peso;
	private double valorUnitario;
	private int qtdeEstoque;
	private List<Pedido> pedidosProduto;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getCounteudodaCaixa() {
		return counteudodaCaixa;
	}
	public void setCounteudodaCaixa(String counteudodaCaixa) {
		this.counteudodaCaixa = counteudodaCaixa;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public double getValorUnitario() {
		return valorUnitario;
	}
	public void setValorUnitario(double valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	public int getQtdeEstoque() {
		return qtdeEstoque;
	}
	public void setQtdeEstoque(int qtdeEstoque) {
		this.qtdeEstoque = qtdeEstoque;
	}
	
	public Produto(int id, String categoria, String counteudodaCaixa,
			String descricao, double peso, double valorUnitario,
			int qtdeEstoque, List<Pedido> pedidosProduto) {
		super();
		this.id = id;
		this.categoria = categoria;
		this.counteudodaCaixa = counteudodaCaixa;
		this.descricao = descricao;
		this.peso = peso;
		this.valorUnitario = valorUnitario;
		this.qtdeEstoque = qtdeEstoque;
		this.pedidosProduto = pedidosProduto;
	}
	
	
}	
	
