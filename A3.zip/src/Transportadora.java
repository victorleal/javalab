import java.util.List;


public class Transportadora {
	
	private String cpnj;
	private String nomeFantasia;
	private String razaoSocial;
	private int prazoEntrega;
	private double taxaEntrega;
	private Endereco endereco;
	private List<Pedido> pedidosTransportadora;
	
	public String getCpnj() {
		return cpnj;
	}
	public void setCpnj(String cpnj) {
		this.cpnj = cpnj;
	}
	public String getNomeFantasia() {
		return nomeFantasia;
	}
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}
	public String getRazaoSocial() {
		return razaoSocial;
	}
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	public int getPrazoEntrega() {
		return prazoEntrega;
	}
	public void setPrazoEntrega(int prazoEntrega) {
		this.prazoEntrega = prazoEntrega;
	}
	public double getTaxaEntrega() {
		return taxaEntrega;
	}
	public void setTaxaEntrega(double taxaEntrega) {
		this.taxaEntrega = taxaEntrega;
	}
	
	public Transportadora(String cpnj, String nomeFantasia, String razaoSocial,
			int prazoEntrega, double taxaEntrega, Endereco endereco,
			List<Pedido> pedidosTransportadora) {
		super();
		this.cpnj = cpnj;
		this.nomeFantasia = nomeFantasia;
		this.razaoSocial = razaoSocial;
		this.prazoEntrega = prazoEntrega;
		this.taxaEntrega = taxaEntrega;
		this.endereco = endereco;
		this.pedidosTransportadora = pedidosTransportadora;
	}
	
}
