import java.util.List;


public class Pedido {
	
	private String numero;
	private double valorTotal;
	private String formaPagamento;
	private String dataCompra;
	private String dataEntrega;
	private Endereco endereco;
	private Cliente cliente;
	private List<Produto> produtosPedido;
	private Transportadora transportadora;
	
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public String getFormaPagamento() {
		return formaPagamento;
	}
	public void setFormaPagamento(String formaPagamento) {
		this.formaPagamento = formaPagamento;
	}
	public String getDataCompra() {
		return dataCompra;
	}
	public void setDataCompra(String dataCompra) {
		this.dataCompra = dataCompra;
	}
	public String getDataEntrega() {
		return dataEntrega;
	}
	public void setDataEntrega(String dataEntrega) {
		this.dataEntrega = dataEntrega;
	}
	
	public Pedido(String numero, double valorTotal, String formaPagamento,
			String dataCompra, String dataEntrega, Endereco endereco,
			Cliente cliente, List<Produto> produtosPedido,
			Transportadora transportadora) {
		super();
		this.numero = numero;
		this.valorTotal = valorTotal;
		this.formaPagamento = formaPagamento;
		this.dataCompra = dataCompra;
		this.dataEntrega = dataEntrega;
		this.endereco = endereco;
		this.cliente = cliente;
		if (produtosPedido == null) {
			System.out.println("Lista Vazia");
		}
		this.produtosPedido = produtosPedido;
		this.transportadora = transportadora;
	}
	
}
	
	
	
	
